export const __userapiurl = "http://localhost:3001/user/";

export const __categoryapiurl = "http://localhost:3001/category/";

export const __subcategoryapiurl = "http://localhost:3001/subcategory/";

export const __productapiurl = "http://localhost:3001/product/";

export const __bidapiurl="http://localhost:3001/bid/";