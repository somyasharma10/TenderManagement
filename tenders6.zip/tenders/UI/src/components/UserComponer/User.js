import './User.css';

function User() {

  return (
    <>
           {/* About Start */}
           <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
                <h1 class="display-5 mb-4">Welcome To <span class="text-primary">Tenders</span></h1>
                <h4 class="text-primary mb-4">User Home Component</h4>
                <p class="mb-4">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit in nobis nam natus provident, voluptatibus amet eos nisi necessitatibus mollitia, repudiandae facilis. Blanditiis ipsam, repudiandae velit magnam, beatae minus amet laudantium suscipit dignissimos placeat non laborum ut! Sit, tenetur. Consequatur minima error, corporis blanditiis, fugit laudantium, repudiandae amet eius at cum necessitatibus minus ducimus hic aperiam. Temporibus vitae maxime, saepe consequatur nesciunt placeat quisquam ipsa blanditiis similique delectus impedit repellendus mollitia ipsum alias laborum doloribus ratione a pariatur explicabo laudantium voluptatem? Molestiae sint non dolores vero? Quisquam sit repellendus, esse, ut adipisci minima, deleniti blanditiis illum modi facilis quam ea?</p>
            </div>
        </div>    
    </div>
    {/* About End */}
    </>
  );
}

export default User;

