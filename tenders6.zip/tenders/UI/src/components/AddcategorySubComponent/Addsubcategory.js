import './Addsubcategory.css';
import axios from 'axios';
import { useState , useEffect } from 'react';
import { __categoryapiurl , __subcategoryapiurl } from '../../API_URL';

function Addsubcategory() {
  const [file, setFile] = useState();
  const [catName , setCatName] = useState();
  const [subCatName , setSubCatName] = useState();
  const [output , setOutput] = useState();
  const [cDetails , setCatDetails] = useState([]);
  useEffect(()=>{
    var condition_obj={};
    axios.get(__categoryapiurl+"fetch",{
      params : { condition_obj : condition_obj }
    }).then((response)=>{
        //console.log(response.data);
        setCatDetails(response.data);
    }).catch((error)=>{
        console.log(error);
    });    
  },[]);

  const handleChange=(event)=>{
    setFile(event.target.files[0]);
  };
  
  const handleSubmit=(event)=>{
    event.preventDefault();
    var formData = new FormData();
    formData.append('catnm', catName);
    formData.append('subcatnm', subCatName);
    formData.append('caticon', file);
    const config = {
        'content-type': 'multipart/form-data'
    };
    axios.post(__subcategoryapiurl+"save", formData, config).then((response) => {
      setCatName("");
      setSubCatName("");
      setOutput("Sub Category Added Successfully....");
    });
  };

  return (
    <>
           {/* About Start */}
           <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">Add <span class="text-primary">Sub Category Here!!!</span></h1>
<font style={{"color":"blue"}} >{output}</font>
<form>
  <div class="form-group">
    <label for="catnm">Category Name:</label>
    <select class="form-control" value={catName} onChange={e => setCatName(e.target.value)}>
      <option>Select Category</option>
      {
        cDetails.map((row)=>(
          <option>{row.catnm}</option>
        ))
      }  
    </select>
  </div>
  <br/>
  <div class="form-group">
    <label for="subcatnm">Sub Category Name:</label>
    <input type="text" class="form-control" value={subCatName} onChange={e => setSubCatName(e.target.value)} />
  </div>
  <br/>
  <div class="form-group">
    <label for="file">Sub Category Icon:</label>
    <input type="file" class="form-control" onChange={handleChange} />
  </div>
  <br/>
  <button onClick={handleSubmit} type="button" class="btn btn-danger">Add Category</button>
</form>                
            </div>
        </div>    
    </div>
    {/* About End */}
    </>
  );
}

export default Addsubcategory;




