import './CPAdmin.css';
import { useState } from 'react';
import axios from 'axios';
import { __userapiurl } from '../../API_URL';
import { useNavigate } from 'react-router-dom';

function CPAdmin() {

  const navigate = useNavigate();
  const [ opassword , setOldPassword ] = useState();
  const [ npassword , setNewPassword ] = useState();
  const [ cnpassword , setConfirmNewPassword ] = useState();
  const [ output , setOutput ] = useState();

  const handleSubmit=()=>{
    var condition_obj={"email":localStorage.getItem("email"),"password":opassword};
    axios.get(__userapiurl+"fetch",{
        params : { condition_obj : condition_obj }
    }).then((response)=>{
      if(npassword==cnpassword)
      {
        var update_details={"condition_obj":{"email":localStorage.getItem("email")} ,"content_obj":{"password":cnpassword}};
        axios.patch(__userapiurl+"update",update_details).then((response)=>{
          alert("Password changes successfully");
          navigate("/logout");
        });  
      } 
      else
      {
        setOutput("New & confirm new password mismatch , please try again....");
        setNewPassword("");
        setConfirmNewPassword("");  
      }     
    }).catch((error)=>{
        setOutput("Invalid old password , please try again....");
        setOldPassword("");
    }); 
   };

  return (
    <>
           {/* About Start */}
           <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<font color="blue">{output}</font>              
<h1 class="display-5 mb-4">Change Password <span class="text-primary">Here!!!</span></h1>
<form>
  <div class="form-group">
    <label for="opwd">Old Password:</label>
    <input type="password" class="form-control" onChange={e=>setOldPassword(e.target.value)} value={opassword} />
  </div>
  <br/>
  <div class="form-group">
    <label for="npwd">New Password:</label>
    <input type="password" class="form-control" onChange={e=>setNewPassword(e.target.value)} value={npassword} />
  </div>
  <br/>

  <div class="form-group">
    <label for="cnpwd">Confirm New Password:</label>
    <input type="password" class="form-control" onChange={e=>setConfirmNewPassword(e.target.value)} value={cnpassword} />
  </div>
  <br/>

  <button type="button" class="btn btn-success" onClick={handleSubmit}>Submit</button>
</form>
            </div>
        </div>    
    </div>
    {/* About End */}
    </>
  );
}

export default CPAdmin;

